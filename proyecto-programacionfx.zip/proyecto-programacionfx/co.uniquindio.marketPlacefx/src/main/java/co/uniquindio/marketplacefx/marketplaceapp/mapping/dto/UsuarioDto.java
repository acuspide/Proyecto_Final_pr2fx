package co.uniquindio.marketplacefx.marketplaceapp.mapping.dto;

public record UsuarioDto(String nickUsuario, String contrasena) {
}
