package co.uniquindio.marketplacefx.marketplaceapp.model;

public class Comentario {
    private String comentario;

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public Comentario(String comentario) {
        this.comentario = comentario;
    }
}