package co.uniquindio.marketplacefx.marketplaceapp.service;

public interface IReporte {
    String getReporte();

}
