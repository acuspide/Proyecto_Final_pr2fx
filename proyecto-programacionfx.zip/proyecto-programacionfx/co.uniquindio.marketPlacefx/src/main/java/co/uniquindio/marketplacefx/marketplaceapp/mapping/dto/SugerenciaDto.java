package co.uniquindio.marketplacefx.marketplaceapp.mapping.dto;

public record SugerenciaDto(String nombre,
                            String nickName) {
}
